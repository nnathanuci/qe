
#include <fstream>
#include <iostream>
#include <cassert>

#include "ix.h"

using namespace std;

void ixTest()
{
}

int main() 
{
  cout << "test..." << endl;

  ixTest();
  // other tests go here

  cout << "OK" << endl;
}
