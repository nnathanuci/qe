
#include <fstream>
#include <iostream>
#include <cassert>

#include "qe.h"

using namespace std;

void opTest()
{
}

int main() 
{
  cout << "test..." << endl;

  opTest();
  // other tests go here

  cout << "OK" << endl;
}
